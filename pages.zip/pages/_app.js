import '../styles/globals.css'
import 'bootstrap/dist/css/bootstrap.min.css'

export function reportWebVitals(metric) {
  // console.log(metric)
}

function MyApp({ Component, pageProps }) {
  return <Component {...pageProps} />
}

export default MyApp
